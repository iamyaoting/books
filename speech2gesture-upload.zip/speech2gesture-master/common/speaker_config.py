# This is the scale factor computed with relation to jon.
# It is relative to jon mostly due to the fact jon was the first speaker in the dataset.

